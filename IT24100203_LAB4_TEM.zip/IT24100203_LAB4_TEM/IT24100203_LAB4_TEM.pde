int state = 0; 
int startTime;
int duration = 20;

float px = 350, py = 175;
float step = 6;
float pr = 20;

float ox = 200, oy = 100;
float xs = 3, ys = 2;
float or = 15;

float hx, hy;
float ease = 0.1;

boolean trails = false;
int score = 0;

void setup() {
  size(700,350);
  hx = px;
  hy = py;
}

void draw() {

  if (!trails) {
    background(245);
  } else {
    fill(245,40);
    noStroke();
    rect(0,0,width,height);
  }
  
  if (state == 0) {
    textAlign(CENTER,CENTER);
    textSize(26);
    fill(0);
    text("Press ENTER to Start", width/2, height/2);
  }

  if (state == 1) {

    int elapsed = (millis() - startTime)/1000;
    int left = duration - elapsed;

    if (left <= 0) {
      state = 2;
    }

    if (keyPressed) {
      if (keyCode == RIGHT) px += step;
      if (keyCode == LEFT)  px -= step;
      if (keyCode == UP)    py -= step;
      if (keyCode == DOWN)  py += step;
    }

    px = constrain(px, pr, width-pr);
    py = constrain(py, pr, height-pr);

    ox += xs;
    oy += ys;

    if (ox > width-or || ox < or) xs *= -1;
    if (oy > height-or || oy < or) ys *= -1;

    hx = hx + (px - hx) * ease;
    hy = hy + (py - hy) * ease;

    float d = dist(px,py,ox,oy);

    if (d < pr + or) {
      score++;

      ox = random(or,width-or);
      oy = random(or,height-or);

      xs *= 1.1;
      ys *= 1.1;
    }

    fill(60,120,200);
    ellipse(px,py,pr*2,pr*2);

    fill(80,200,120);
    ellipse(hx,hy,16,16);

    fill(240,120,80);
    ellipse(ox,oy,or*2,or*2);

    fill(0);
    textAlign(LEFT,TOP);
    textSize(16);
    text("Score: "+score,20,20);
    text("Time: "+left,20,40);
    text("Press T for Trails",20,60);
  }

  if (state == 2) {
    background(245);
    textAlign(CENTER,CENTER);
    textSize(26);
    fill(0);
    text(" Time is Over!\nScore: "+score+"\nPress R to Restart", width/2, height/2);
  }
}

void keyPressed() {

  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
    score = 0;
  }

  if (key == 't' || key == 'T') {
    trails = !trails;
  }

  if (state == 2 && (key == 'r' || key == 'R')) {
    state = 0;

    px = width/2;
    py = height/2;

    xs = 3;
    ys = 2;
  }
}
